Author: Benjamin Vander Klay (bcvander)
Class: ECE121/L Winter 2022 Prof Petersen
Assignment: Lab0 due 1/14/2022






README for Lab0. Checking to see that git is working :)
