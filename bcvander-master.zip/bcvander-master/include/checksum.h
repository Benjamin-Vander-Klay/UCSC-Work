/* 
 * File:   checksum.h
 * Author: Ben Vander Klay
 *
 * Created on January 20, 2022, 9:13 PM
 */

#ifndef CHECKSUM_H
#define	CHECKSUM_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* CHECKSUM_H */

